#ifndef _xstrtoul_h_
#define _xstrtoul_h_ 1

#define STRING_TO_UNSIGNED 1
#include "xstrtol.h"

#endif /* _xstrtoul_h_ */
